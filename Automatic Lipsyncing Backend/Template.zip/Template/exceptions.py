# Borrowed from: https://github.com/kylebgorman/textgrid/tree/master/textgrid 
class TextGridError(Exception):
    pass